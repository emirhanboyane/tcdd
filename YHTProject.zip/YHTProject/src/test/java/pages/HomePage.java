package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.Driver;

import java.util.List;

public class HomePage {
    public HomePage() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    @FindBy(xpath = "//input[@id='nereden']")
    public WebElement nereden;

    @FindBy(xpath = "//input[@id='nereye']")
    public WebElement nereye;

    @FindBy(xpath = "//input[@id='trCalGid_input']")
    public WebElement gidisTarihi;

    @FindBy(xpath = "//input[@id='trCalDon_input']")
    public WebElement donusTarihi;

    @FindBy(xpath = "//button[@id='btnSeferSorgula']")
    public WebElement araButonu;

    @FindBy(xpath = "//a[@class='ui-corner-all']")
    public WebElement acilirListe;

    @FindBy(xpath = "//a[.='Ankara Gar']")
    public WebElement ankaraGari;

}
