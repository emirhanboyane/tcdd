package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.Driver;

import java.util.List;

public class KoltukSecimiPage {

    public KoltukSecimiPage() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    @FindBy(xpath = "//input[@class='ui-wagon-item-checkbox']")
    public List<WebElement> bosKoltuklar;

    @FindBy(xpath = "//button[@id='mainTabView:j_idt206:2:gidisVagonlariGost']")
    public WebElement digerVagon;

}
