package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.Driver;

import java.util.List;

public class SeferSecimiPage {

    public SeferSecimiPage() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    @FindBy(xpath = "//div[@type='button']")
    public List<WebElement> secButonlari;

    @FindBy(xpath = "//button[@id='mainTabView:btnDevam44']")
    public WebElement devamButonu;
}
