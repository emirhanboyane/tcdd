package stepdefinitions;

import io.cucumber.java.en.*;
import org.junit.Assert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pages.HomePage;
import pages.KoltukSecimiPage;
import pages.SeferSecimiPage;
import utilities.ConfigReader;
import utilities.Driver;

import java.time.Duration;

public class BosKoltukBulStepDefinition {

    WebDriverWait wait = new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(10));
    Actions actions = new Actions(Driver.getDriver());
    HomePage homePage = new HomePage();
    KoltukSecimiPage koltukSecimiPage = new KoltukSecimiPage();
    SeferSecimiPage seferSecimiPage = new SeferSecimiPage();
    @When("kullanici siteye gider")
    public void kullanici_siteye_gider() {
        Driver.getDriver().get(ConfigReader.getProperty("url"));
    }
    @When("kullanici Nereden alaninda {string} secer")
    public void kullanici_nereden_alaninda_secer(String string) {
        homePage.nereden.sendKeys(string);
        wait.until(ExpectedConditions.visibilityOf(homePage.acilirListe));
        homePage.acilirListe.click();
//        actions.sendKeys(homePage.nereden, Keys.ARROW_DOWN, Keys.ENTER);
    }
    @When("kullanici Nereye alaninda {string} secer")
    public void kullanici_nereye_alaninda_secer(String string) {
        homePage.nereye.sendKeys(string);
        wait.until(ExpectedConditions.visibilityOf(homePage.ankaraGari));
        homePage.ankaraGari.click();
    }
    @When("kullanici Ara butonuna tiklar")
    public void kullanici_ara_butonuna_tiklar() {
        homePage.araButonu.click();
    }

    @Then("kullanici Sec butonuna isaretler")
    public void kullaniciSecButonunaIsaretler() {
        seferSecimiPage.secButonlari.get(0).click();
    }

    @And("kullanici Devam butonuna tiklar")
    public void kullaniciDevamButonunaTiklar() {
        seferSecimiPage.devamButonu.click();
    }

    @And("kullanici bos bir koltuk secer bos koltuk yoksa diger vagona gecer")
    public void kullaniciBosBirKoltukSecerBosKoltukYoksaDigerVagonaGecer() {
        try {
            koltukSecimiPage.bosKoltuklar.get(0).click();
            wait.until(ExpectedConditions.elementToBeSelected(koltukSecimiPage.bosKoltuklar.get(0)));
            Assert.assertTrue(koltukSecimiPage.bosKoltuklar.get(0).isSelected());
        }catch (NoSuchElementException e){
            koltukSecimiPage.digerVagon.click();
        }
    }
}
